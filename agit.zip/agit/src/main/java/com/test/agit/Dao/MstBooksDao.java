package com.test.agit.Dao;

import com.test.agit.Entity.MstBooks;

import java.util.List;
import java.util.Optional;

public interface MstBooksDao {

    public Optional<MstBooks> findbyId(String idBooks);

    public List<MstBooks> findAllByStatus(String status);
}
