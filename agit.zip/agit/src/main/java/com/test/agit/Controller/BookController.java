package com.test.agit.Controller;

import com.test.agit.Entity.MstBooks;
import com.test.agit.Repository.BookRepository;
import com.test.agit.Service.BookService;
import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping("/findAll")
    public ResponseEntity<?> findAllBooks(
            @RequestParam(value = "status", required = false) String bookStatus) {

                return ResponseEntity.ok().body(bookService.getFindAll(bookStatus));


    }

    @PostMapping("/save")
    public ResponseEntity<?> saveBooks(@RequestBody MstBooks mstBooks)
            {

        return ResponseEntity.ok().body(bookService.saveBooks(mstBooks));
    }

    @PostMapping("/update")
    public ResponseEntity<String> updateBooks(@RequestParam(value = "idbooks") String idbooks,
                                         @RequestBody MstBooks mstBooks) throws Exception {

        return ResponseEntity.ok().body(bookService.updateBooks(mstBooks, idbooks));
    }

    @PostMapping("/delete")
    public ResponseEntity<String> deleteBooks(@RequestParam(value = "idbooks") String idbooks) throws Exception {
        return ResponseEntity.ok().body(bookService.deletedBooks(idbooks));
    }
}
