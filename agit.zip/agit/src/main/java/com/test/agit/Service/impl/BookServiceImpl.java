package com.test.agit.Service.impl;

import com.test.agit.Dao.MstBooksDao;
import com.test.agit.Dao.impl.MstBooksDaoImpl;
import com.test.agit.Entity.MstBooks;
import com.test.agit.Exception.ResourceNotFoundException;
import com.test.agit.Repository.BookRepository;
import com.test.agit.Service.BookService;
import org.hibernate.cache.CacheException;
import org.hibernate.service.spi.ServiceException;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


@Service
public class BookServiceImpl implements BookService {
    private Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private MstBooksDao dao;

    @Autowired
    private BookRepository bookRepository;

    @Override
    public MstBooks saveBooks(MstBooks books){

        if (books.getId_buku().isEmpty() || books.getId_buku() == null){
            throw new ResourceNotFoundException("Error Books does not exists ");
        }
        Optional<MstBooks> mstBooks =  dao.findbyId(books.getId_buku());
        if(mstBooks.isPresent()){
            if (Objects.nonNull(books.getPengarang()) && !"".equals(books.getPengarang())){
                mstBooks.get().setPengarang(books.getPengarang());
            }
            if (Objects.nonNull(books.getPenerbit()) && !"".equals(books.getPenerbit())){
                mstBooks.get().setPenerbit(books.getPenerbit());
            }
            if (Objects.nonNull(books.getTebal_buku()) && !"".equals(books.getTebal_buku())){
                mstBooks.get().setTebal_buku(books.getTebal_buku());
            }
            if (Objects.nonNull(books.getJudul()) && !"".equals(books.getJudul())){
                mstBooks.get().setJudul(books.getJudul());
            }
            if (Objects.nonNull(books.getTanggal_terbit()) && !"".equals(books.getTanggal_terbit())){
                mstBooks.get().setTanggal_terbit(books.getTanggal_terbit());
            }
            if (Objects.nonNull(books.getStatus()) && !"".equals(books.getStatus())){
                mstBooks.get().setStatus(books.getStatus());
            }
            if (Objects.nonNull(books.getPeminjam()) && !"".equals(books.getPeminjam())){
                mstBooks.get().setPeminjam(books.getPeminjam());
            }
            if (Objects.nonNull(books.getTanggal_pinjam()) && !"".equals(books.getTanggal_pinjam())){
                mstBooks.get().setTanggal_pinjam(books.getTanggal_pinjam());
            }
            if (Objects.nonNull(books.getTanggal_kembali()) && !"".equals(books.getTanggal_kembali())){
                mstBooks.get().setTanggal_kembali(books.getTanggal_kembali());
            }
            bookRepository.save(mstBooks.get());
        }else {
            try{
                books.setStatus("0");
                books.setPeminjam("-");
                books.setTanggal_kembali("-");
                books.setTanggal_pinjam("-");
                bookRepository.save(books);
            }catch (CacheException e){
                throw new ResourceNotFoundException("Error Save Data: " + books.getId_buku());
            }

        }
        return books;
    }

    @Override
    public List<MstBooks> getFindAll(String bookStatus) throws ServiceException {
        List<MstBooks> mstBooksList = new ArrayList<>();
        if (bookStatus == null || bookStatus.isEmpty()){
             mstBooksList = bookRepository.findAll();
        }else{
                mstBooksList = bookRepository.findAllByStatus(bookStatus);

        }

        return mstBooksList;
    }



    @Override
    public String updateBooks(MstBooks books, String idbooks) throws Exception {
        if (idbooks.isEmpty() || idbooks == null){
            throw new ResourceNotFoundException("Books does not exists :  " + books.getId_buku());
//            throw new ServiceException(BaseErrorCode.COOM_003.getDescription());
        }
        Optional<MstBooks> mstBooks =  dao.findbyId(idbooks);
        if (mstBooks.isPresent()){
            if(checkDataBorrower(books)){

                mstBooks.get().setTanggal_pinjam(books.getTanggal_pinjam());
                mstBooks.get().setTanggal_kembali(books.getTanggal_kembali());
                mstBooks.get().setPeminjam(books.getPeminjam());
                mstBooks.get().setStatus("1");
                bookRepository.save(mstBooks.get());
            }
        }
        return "ok";
    }

    @Override
    public String deletedBooks(String booksId) throws Exception {
        Optional<MstBooks> mstBooks =  dao.findbyId(booksId);
        if(mstBooks.isPresent()){
            try{
                bookRepository.deleteById(booksId);
            }catch (CacheException e){
                throw new ResourceNotFoundException("Error Delete Books :  " + booksId);
            }
        }


        return "ok";
    }

    private boolean checkDataBorrower(MstBooks mstBooks) throws Exception{
        boolean flag = false;
        if(dateStringFilterValidation(mstBooks.getTanggal_pinjam(), mstBooks.getTanggal_kembali())){
            if (!mstBooks.getPeminjam().equals("") && null != mstBooks.getPeminjam()){
                flag = true;
            }
        }
        return flag;
    }

    private boolean dateStringFilterValidation(String dateFrom, String dateTo) throws Exception{
        boolean flag = false;
        try{
            SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy");
            Date dtForm =  sdf.parse(dateFrom);
            Date dtTo = sdf.parse(dateTo);
            flag = dateFilterValidation(dtForm, dtTo);
        }catch (ParseException pe){
            throw new Exception(pe.getMessage());
        }
        return flag;
    }

    private boolean dateFilterValidation(Date dateFrom , Date dateTo) throws Exception{
        boolean flag = false;
        if (dateFrom == null && dateTo == null){
            throw new ResourceNotFoundException("Invalid Date");
        }
        if (null !=  dateFrom && null != dateTo && dateFrom.after(dateTo)){
            throw new ResourceNotFoundException("Date From more than Date To");
        }

        if (null !=  dateFrom && null != dateTo && dateTo.after(dateFrom)){
            flag = true;
        }
        return flag;
    }
}
