package com.test.agit.Entity;

import jdk.nashorn.internal.objects.annotations.Getter;
import jdk.nashorn.internal.objects.annotations.Setter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
//
@Entity
@Table(name="mst_books")
public class MstBooks {

    @Id
    @Column(nullable = false, name = "id_buku")
    private String id_buku;

//    @Column(nullable = false, name = "pengarang")

    @Column(nullable = false, name = "penerbit")
    private String penerbit;

    @Column(nullable = false, name = "pengarang")
    private String pengarang;

    @Column(nullable = false, name  = "tebal_buku")
    private String tebal_buku;

    @Column(nullable = false, name ="judul")
    private String judul;

    @Column(nullable = false, name = "tanggal_terbit")
    private String tanggal_terbit;

    @Column(nullable = false, name = "status")
    private String status;

    @Column(nullable = false, name = "peminjam")
    private String peminjam;

    @Column(nullable = false, name = "tanggal_pinjam")
    private String tanggal_pinjam;

    @Column(nullable = false, name = "tanggal_kembali")
    private String tanggal_kembali;

    public String getId_buku() {
        return id_buku;
    }

    public void setId_buku(String id_buku) {
        this.id_buku = id_buku;
    }

    public String getPenerbit() {
        return penerbit;
    }

    public void setPenerbit(String penerbit) {
        this.penerbit = penerbit;
    }

    public String getPengarang() {
        return pengarang;
    }

    public void setPengarang(String pengarang) {
        this.pengarang = pengarang;
    }



    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getTebal_buku() {
        return tebal_buku;
    }

    public void setTebal_buku(String tebal_buku) {
        this.tebal_buku = tebal_buku;
    }

    public String getTanggal_terbit() {
        return tanggal_terbit;
    }

    public void setTanggal_terbit(String tanggal_terbit) {
        this.tanggal_terbit = tanggal_terbit;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPeminjam() {
        return peminjam;
    }

    public void setPeminjam(String peminjam) {
        this.peminjam = peminjam;
    }

    public String getTanggal_pinjam() {
        return tanggal_pinjam;
    }

    public void setTanggal_pinjam(String tanggal_pinjam) {
        this.tanggal_pinjam = tanggal_pinjam;
    }

    public String getTanggal_kembali() {
        return tanggal_kembali;
    }

    public void setTanggal_kembali(String tanggal_kembali) {
        this.tanggal_kembali = tanggal_kembali;
    }

}
