package com.test.agit.Repository;

import com.test.agit.Entity.MstBooks;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BookRepository extends JpaRepository<MstBooks,String> {

    @Query("SELECT p From MstBooks p WHERE p.status = :status")
    List<MstBooks> findAllByStatus(@Param("status") String status);

    @Query("SELECT p From MstBooks p WHERE p.id_buku = :idBooks")
    Optional<MstBooks> findById(@Param("idBooks") String idBooks);
}
