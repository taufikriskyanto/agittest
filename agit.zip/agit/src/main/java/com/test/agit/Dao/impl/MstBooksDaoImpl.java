package com.test.agit.Dao.impl;

import com.test.agit.Dao.MstBooksDao;
import com.test.agit.Entity.MstBooks;
import com.test.agit.Repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MstBooksDaoImpl implements MstBooksDao {
    @Autowired
    private BookRepository repository;
    @Override
    public Optional<MstBooks> findbyId(String idBooks) {
        return repository.findById(idBooks);
    }

    @Override
    public List<MstBooks> findAllByStatus(String status) {
        return repository.findAllByStatus(status);
    }
}
