package com.test.agit.Service;

import com.test.agit.Entity.MstBooks;
import org.hibernate.service.spi.ServiceException;

import java.util.List;

public interface BookService {

    public MstBooks saveBooks (MstBooks books);

    public List<MstBooks> getFindAll (String bookStatus);

    public String updateBooks (MstBooks books, String idbooks) throws Exception;

    public String deletedBooks (String booksId) throws Exception;
}
